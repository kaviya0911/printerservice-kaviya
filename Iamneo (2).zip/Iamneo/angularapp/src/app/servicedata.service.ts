import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { addService } from './addcenter/addService';

@Injectable({
  providedIn: 'root'
})
export class ServicedataService {
url="http://localhost:5002/user/signup";
url2="http://localhost:5002/admin"
admin="http://localhost:5002/service/addservice";
base="http://localhost:5002/service";
baseurl1="http://localhost:5002/auth/loginpage";
url3="http://localhost:5002"
 constructor(private http:HttpClient) { }

//   public adminLogin(admin:ServicedataService)
//   {
//     return this.http.get<ServicedataService>(this.baseurl1+'/'+admin.);
//   }
// adminLogin(admin:loginModel)
// {
//   return this.http.post(`${this.url2}/login`,admin)
// }

saveBooks(data:any){
    return this.http.post(this.url,data);
  }
// login(log:loginModel):Observable<object>
// {
// return this.http.post(`${this.baseurl1}`,log);

// }

 saveprinter(data:any){
  console.log(data);
  return this.http.post(this.url3+'/appointment/saveappointment',data);
 }

getprinter(){
  return this.http.get(this.url3+'/appointment/getappointment');
}
deleteappointment(productId:any){
  return this.http.delete(this.url3+'/appointment/deleteappointment/'+productId);
}
url1="http://localhost:5002/appointment/editappointment/{id}";
updateappointment(productId:any){
  return this.http.put(this.url1,productId);
}


addnewService1(add:addService):Observable<object>
{

return this.http.post(`${this.admin}`,add);
}
getAllServices():Observable<addService[]>{
return this.http.get<addService[]>(`${this.base}/getservice`);
}
updateService(id:string,da:addService):Observable<object>{
  return this.http.put(`${this.base}/editservice/${id}`,da)
}
delete(id:string):Observable<object>
{
return this.http.delete(`${this.base}/deleteservice/${id}`);
}


}
