import { Component } from '@angular/core';
import { ServicedataService } from '../servicedata.service';
import { Router} from '@angular/router'

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent {
  printer:any;
  constructor(private userdata:ServicedataService,private router: Router){

    this.userdata.getprinter().subscribe((data)=>{
      console.log("data",data);
      this.printer=data;
     })
  }

  deleteAppointment(productId:any){
    console.log(productId);
    this.userdata.deleteappointment(productId).subscribe((result)=>{
      console.log(result);
      
    })
}
editAppointment(data:any){
  this.router.navigate(['editappointment'],{state:{printer:data}});
}

}
