import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { AuthComponent } from './auth/auth.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { CenterprofileComponent } from './centerprofile/centerprofile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LaserprinterComponent } from './mediaservice/laserprinter.component';
import { LEDprinterComponent } from './printerservice/ledprinter.component';
import { INKprinterComponent } from './moontechservice/inkprinter.component';
import { EditappointmentComponent } from './editappointment/editappointment.component';
// import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AdmineditComponent } from './adminedit/adminedit.component';
import { ServicedataService } from './servicedata.service';
import { AppService } from './app.service';



@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    HomepageComponent,
    DashboardComponent,
    AppointmentComponent,
    AddcenterComponent,
    CenterprofileComponent,
    LaserprinterComponent,
    LEDprinterComponent,
    INKprinterComponent,
    EditappointmentComponent,
    AdmineditComponent,
    
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule,
    AppRoutingModule,
    NgbModule, BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,

  ],
  providers: [
    ServicedataService,AppService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
