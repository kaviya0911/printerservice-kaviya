import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicedataService } from '../servicedata.service';
import { addService } from '../addcenter/addService';

@Component({
  selector: 'app-centerprofile',
  templateUrl: './centerprofile.component.html',
  styleUrls: ['./centerprofile.component.css']
})
export class CenterprofileComponent {

ser:addService[]={}as addService[];
  constructor(private gett:ServicedataService){}
  ngOnInit():void{
this.gett.getAllServices().subscribe(data=>{
  this.ser=data;
}
  )
  }
  CenterProfile=new FormGroup({

    editName:new FormControl(''),
    editNumber:new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
    editAddress:new FormControl(''),
    editImageUrl:new FormControl(''),
    editEmail:new FormControl(''),
    editCentreDescription:new FormControl('')

  })
  
  get f()
  {
    return this.CenterProfile.controls;
  }

  Update()
  {
    console.log(this.CenterProfile.value);
  }
delete(id:string)
{
  this.gett.delete(id).subscribe(data=>{
    alert("dleted sucessfully")
  },error=>alert("cant delete"))
}


}
