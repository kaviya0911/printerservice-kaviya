import { ComponentFixture, TestBed } from '@angular/core/testing';

import { INKprinterComponent } from './inkprinter.component';

describe('INKprinterComponent', () => {
  let component: INKprinterComponent;
  let fixture: ComponentFixture<INKprinterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ INKprinterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(INKprinterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
