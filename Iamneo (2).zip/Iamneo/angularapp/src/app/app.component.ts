import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Project';
//   Login=new FormGroup(
//     {
//       email:new FormControl('',[Validators.required,Validators.email]),
//       password:new FormControl('')
    
//     }
//   )

//   LoginForm(){
//     // if(authenticated && authorized){
//     //   if(email === "admin")
//     // }
//     console.log(this.Login.value);
//   }
// get email(){

//   return this.Login.get('email')
// }

}
