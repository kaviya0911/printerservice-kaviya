import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicedataService } from '../servicedata.service';

@Component({
  selector: 'app-ledprinter',
  templateUrl: './ledprinter.component.html',
  styleUrls: ['./ledprinter.component.css']
})
export class LEDprinterComponent implements OnInit {

constructor(private userdata:ServicedataService){}
ngOnInit(): void {
  
}
Dashboard=new FormGroup(
  {
  productName:new FormControl('',[Validators.required]),
  productModelNo:new FormControl('',[Validators.required]),
  dateOfPurchase:new FormControl('',[Validators.required]),
  contactNumber:new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
  problemDescription:new FormControl('',Validators.required),
  availableSlots:new FormControl('',Validators.required)
  }
)

appointment(){
   this.userdata.saveprinter(this.Dashboard.value).subscribe((result)=>{
    console.log(result);
   });
    alert("Appointment fixed");
  } 

  get contactNumber(){
    return this.Dashboard.get('contactNumber');
  }

}






