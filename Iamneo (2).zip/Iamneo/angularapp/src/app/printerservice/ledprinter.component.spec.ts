import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LEDprinterComponent } from './ledprinter.component';

describe('LEDprinterComponent', () => {
  let component: LEDprinterComponent;
  let fixture: ComponentFixture<LEDprinterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LEDprinterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LEDprinterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
