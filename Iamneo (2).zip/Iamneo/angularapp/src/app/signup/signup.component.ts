import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicedataService } from '../servicedata.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../app.service';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {


  Registration=new FormGroup(

    {
      email:new FormControl('',[Validators.required,Validators.email]),
      username:new FormControl('',[Validators.required]), 
      mobileNumber:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
      password:new FormControl('',[Validators.required]),
     confirmPassword:new FormControl('',[Validators.required]),
      userRole:new FormControl('',[Validators.required])
    }
  )
  constructor(private route:ActivatedRoute,
    private router:Router,
    private appService:AppService){}
  RegForm(){
    console.log(this.Registration.value);
    if(this.Registration.status=='VALID'){
      this.appService.register({email:this.Registration.controls.email.value , password:this.Registration.controls.password.value ,username:this.Registration.controls.username.value, mobileNumber:this.Registration.controls.mobileNumber.value ,userRole:this.Registration.controls.userRole.value ,}).subscribe((result)=>
      {
        console.log(result);
        this.router.navigate(['/signup']);
        alert("register Successfully");
      })
    }
    else{
      alert("All fields are required");
    }
  }

   get email(){
    return this.Registration.get('email')
  }

   get mobileNumber(){
       return this.Registration.get('mobileNumber')
 }

  
}





