export interface addService{
    serviceCenterID:string;
serviceCenterName:string;
serviceCenterPhone:string;
serviceCenterAddress:string;
serviceCentermailId:string;
serviceCenterDescription:string;

}

 