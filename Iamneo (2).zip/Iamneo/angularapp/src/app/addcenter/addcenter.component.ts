import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { addService } from './addService';
import { ServicedataService } from '../servicedata.service';

@Component({
  selector: 'app-addcenter',
  templateUrl: './addcenter.component.html',
  styleUrls: ['./addcenter.component.css']
})
export class AddcenterComponent {
d1:addService={} as addService;  
  constructor(private add:ServicedataService){

  }
  addService()
  {
    this.add.addnewService1(this.d1).subscribe(data=>
      {alert("new service added sucessfully")},error=>alert("cant add service"))
    console.log(this.d1);
  }

}
