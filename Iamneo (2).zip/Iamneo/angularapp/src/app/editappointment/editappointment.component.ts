import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicedataService } from '../servicedata.service';
import { Router} from '@angular/router'

@Component({
  selector: 'app-editappointment',
  templateUrl: './editappointment.component.html',
  styleUrls: ['./editappointment.component.css']
})
export class EditappointmentComponent {
  EditAppointment: FormGroup;

constructor(private userdata:ServicedataService,private router: Router)
{
const statedata:any=this.router.getCurrentNavigation()?.extras.state;
this.EditAppointment=new FormGroup(
  { 
    productId:new FormControl(statedata.printer.productId,[Validators.required]),
    productName:new FormControl(statedata.printer.productName,[Validators.required]),
    productModelNo:new FormControl(statedata.printer.productModelNo,[Validators.required]),
    dateOfPurchase:new FormControl(statedata.printer.dateOfPurchase,[Validators.required]),
    contactNumber:new FormControl(statedata.printer.contactNumber,[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
    problemDescription:new FormControl(statedata.printer.problemDescription,[Validators.required]),
    availableSlots:new FormControl(statedata.printer.availableSlots,[Validators.required])
})
}
ngOnInit(): void {
 
}
updateappointment(){
  this.userdata.saveprinter(this.EditAppointment.value).subscribe((result)=>{
   console.log(result);
   this.router.navigate(['appointment']);
  });
   alert("Appointment updated");
 } 

 get contactNumber(){
   return this.EditAppointment.get('contactNumber');
 }

}

