import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { addService } from '../addcenter/addService';
import { ServicedataService } from '../servicedata.service';

@Component({
  selector: 'app-adminedit',
  templateUrl: './adminedit.component.html',
  styleUrls: ['./adminedit.component.css']
})
export class AdmineditComponent {
  id:string="";
  upd:addService={} as addService;
  constructor(private activatedroute:ActivatedRoute,private up:ServicedataService){}

  ngOnInit():void{
this.id=''+this.activatedroute.snapshot.paramMap.get('id');

  }
  CenterProfile=new FormGroup({

    editName:new FormControl(''),
    editNumber:new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
    editAddress:new FormControl(''),
    editImageUrl:new FormControl(''),
    editEmail:new FormControl(''),
    editCentreDescription:new FormControl('')

  })
  
  get f()
  {
    return this.CenterProfile.controls;
  }

  updateService()
  {
    this.up.updateService(this.id,this.upd).subscribe(data=>{
      alert("update sucessfull")
    },error=>alert("something wrong"))
    console.log(this.CenterProfile.value);
  }

}


