import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaserprinterComponent } from './laserprinter.component';

describe('LaserprinterComponent', () => {
  let component: LaserprinterComponent;
  let fixture: ComponentFixture<LaserprinterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LaserprinterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LaserprinterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
