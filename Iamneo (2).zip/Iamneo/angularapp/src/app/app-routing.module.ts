import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { LoginComponent } from './login/login.component';
import { LaserprinterComponent } from './mediaservice/laserprinter.component';
import { LEDprinterComponent } from './printerservice/ledprinter.component';
import { INKprinterComponent } from './moontechservice/inkprinter.component';

import { CenterprofileComponent } from './centerprofile/centerprofile.component';
import { SignupComponent } from './signup/signup.component';
import { EditappointmentComponent } from './editappointment/editappointment.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { AdmineditComponent } from './adminedit/adminedit.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:'login',
    pathMatch:'full'
  },
  
    {
      path:'homepage',
      component:HomepageComponent
    },
    { 
      path:'dashboard',
      component:DashboardComponent
    },
    {
      path:'appointment', 
      component:AppointmentComponent
    },
    {
      path:'login', 
      component:LoginComponent
    },
    {
      path:'inkprinter', 
      component:INKprinterComponent
    },
    {
      path:'laserprinter', 
      component:LaserprinterComponent
    },
    {
      path:'ledprinter', 
      component:LEDprinterComponent
    },
    {
      path:'appointment/',
      component:AppointmentComponent
    },
    {
      path:'centerprofile',
      component:CenterprofileComponent
    },
    {
      path:'signup',
      component:SignupComponent
    },
    {
      path:'login',
      component:LoginComponent
    },
    {
      path:'editappointment',
      component:EditappointmentComponent
    },
    {
      path:'addcenter',
      component:AddcenterComponent
    },
    {
      path:'adminedit/:id',
      component:AdmineditComponent
    }
  
  
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
