import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  loggedInUserDetails: any;
url="http://localhost:5002" 

  constructor(private htt:HttpClient) { }
  login(email:any,password:any){
    return this.htt.post(this.url+'/user/login',{
        email:email , password: password,username:null,
        mobileNumber:null,
        userRole: null
    });
  }

  register(data:any){
   return this.htt.post(this.url+'/user/signup',data);
  }
  getUserDetailByEmail(email?: string){
    return this.htt.get(this.url+'/user/'+email);
  }

  getLoggedInUserDetails(){
    return this.loggedInUserDetails;
  }
  setLoggedInUserDetails(data: any){
    this.loggedInUserDetails = data;
  }
}
