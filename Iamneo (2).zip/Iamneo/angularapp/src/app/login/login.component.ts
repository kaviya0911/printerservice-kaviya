import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServicedataService } from '../servicedata.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../app.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {


Login=new FormGroup(
  {
    email:new FormControl('',[Validators.required,Validators.email]),

    password:new FormControl('',[Validators.required])

  }

)
constructor(
private route: ActivatedRoute,
private router: Router ,
private appService: AppService ) {}
  


LoginForm(){
if(this.Login.status=='VALID'){
this.appService.login(this.Login.controls.email.value, this.Login.controls.password.value).subscribe((result)=>
{
  if(result==true){
    console.log(result);
  this.appService.getUserDetailByEmail(this.Login.controls.email.value ? this.Login.controls.email.value:'')
  .subscribe((data:any)=>{
    this.appService.setLoggedInUserDetails(data);
    if(data.userRole=="Admin"){

      this.router.navigate(['centerprofile' ]);
    }else{
      this.router.navigate(['homepage' ]);
    }
    
  })
  }else{
    alert("wrong credentials");
  }
  
})

}

else{
alert("Username and password are required");
}
  console.log(this.Login);
}
get email(){

return this.Login.get('email')

}

get password(){

  return this.Login.get('password')

 }


 }




