package com.example.PrinterService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.PrinterService.Model.LoginModel;
import com.example.PrinterService.Model.UserModel;
import com.example.PrinterService.Service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins="http://localhost:4200")
public class AuthController {

              
              @Autowired
              public AuthService authservice;
             
              @PostMapping("/loginpage")
              public boolean isUserPresent(@RequestBody LoginModel data){
                             return authservice.checkLogin(data);
              }
              @PostMapping("/signuppage")
              public LoginModel sigupuser(@RequestBody LoginModel loginmodel) {
                             return authservice.adduser(loginmodel);
                             
              }
              }
